$(document).on('click','.delete-button', function() {
    return confirm('Are you sure want to delete this?')
});
