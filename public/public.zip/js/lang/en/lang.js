var select_department = 'Please Choose Department';
var message_get_it_callback = {
    'title': 'Error',
    'message' : 'Please choose department and counter'
}
var choose_department_callback = {
    'title': 'Sorry, registration is closed',
    'message' : 'We are sorry but registration is closed at this branch, please try checking another branch, thank you.'
}
var success_token_callback = {
    'title': 'Your token',
    'message' : 'Sent! Please check your email or SMS. ',
    'more_message': '<b>Scan The QR</b> or click <b>\'Get My Token\'</b> button, to get your token.',
    'close_popup' : 'This popup will close in 60s.',
    'button_get_token' : 'Get My Token',
    'close_button' : 'Close',
}
var message_error_sms_callback = {
    'title': 'Error',
    'message' : 'Please check your Twilio SID, token, etc, also the user number.'
}
var token_message_error_callback = {
    'title': 'Error',
    'message' : 'Please fill your email.'
}
var token_message_success_callback = {
    'title': 'Success',
    'message' : 'Sent! Please check your email.'
}
