var select_department = 'Scegli reparto';
var message_get_it_callback = {
    'title': 'Error',
    'message': 'Si prega di scegliere reparto e contatore'
}
var choose_department_callback = {
    'title': 'Spiacenti, la registrazione è chiusa',
    'message': 'Siamo spiacenti ma la registrazione è chiusa in questa filiale, prova a controllare un\'altra filiale, grazie.'
}
var success_token_callback = {
    'title': 'Your token',
    'message': 'Inviato! Per favore controlla la tua email o SMS. ',
    'more_message': '<b>Scansiona il QR</b> o fai clic sul pulsante <b>\'Ottieni il mio token\'</b> per ottenere il tuo token.',
    'close_popup': 'Questo popup si chiuderà tra 60s.',
    'button_get_token': 'Ottieni il mio token',
    'close_button': 'Chiudi',
}
var message_error_sms_callback = {
    'title': 'Error',
    'message': 'Controlla il tuo Twilio SID, token, ecc. anche il numero utente.'
}
var token_message_error_callback = {
    'title': 'Error',
    'message': 'Inserisci la tua email.'
}
var token_message_success_callback = {
    'title': 'Success',
    'message': 'Inviato! Si prega di controllare la tua email.'
}