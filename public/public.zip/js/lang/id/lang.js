var select_department = 'Silahkan Pilih Department';
var message_get_it_callback = {
    'title': 'Kesalahan',
    'message' : 'Silahkan pilih kantor cabang dan department'
}
var choose_department_callback = {
    'title': 'Maaf, Pendaftaran ditutup',
    'message' : 'Kami mohon maaf tetapi pendaftaran ditutup di cabang ini, silakan coba periksa cabang lain, terima kasih.'
}
var success_token_callback = {
    'title': 'Token Anda',
    'message' : 'Terkirim! Silahkan cek email atau SMS Anda. ',
    'more_message': '<b>Pindai QR</b> atau klik tombol <b>\'Dapatkan Token Saya\'</b>, untuk mendapatkan token Anda.',
    'close_popup' : 'Popup akan tertutup dalam 60s.',
    'button_get_token' : 'Dapatkan Token Saya',
    'close_button' : 'Tutup',
}
var message_error_sms_callback = {
    'title': 'Kesalahan',
    'message' : 'Silakan periksa Twilio SID Anda, token, dll, juga nomor pengguna.'
}
var token_message_error_callback = {
    'title': 'Kesalahan',
    'message' : 'Silahkan isi email Anda.'
}
var token_message_success_callback = {
    'title': 'Berhsil',
    'message' : 'Terkirim! Silahkan cek email Anda.'
}
