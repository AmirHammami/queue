var select_department = 'Veuillez choisir un service';
var message_get_it_callback = {
    'title': 'Erreur',
    'message': 'Veuillez choisir le département et le compteur'
}
var choose_department_callback = {
    'title': 'Désolé, les inscriptions sont terminées',
    'message': 'Nous sommes désolés mais l\'inscription est fermée dans cette succursale, veuillez essayer de vérifier une autre succursale, merci.'
}
var success_token_callback = {
    'title': 'Votre jeton',
    'message': 'Envoyé! Veuillez vérifier votre email ou SMS. ',
    'more_message': '<b>Scannez le QR</b> ou cliquez sur le bouton <b>\'Obtenir mon jeton\'</b> pour obtenir votre token.',
    'close_popup': 'Cette popup se fermera dans 60s.',
    'button_get_token': 'Obtenir mon jeton',
    'close_button': 'Fermer',
}
var message_error_sms_callback = {
    'title': 'Erreur',
    'message': 'Veuillez vérifier votre SID Twilio, votre token, etc., ainsi que le numéro d\'utilisateur.'
}
var token_message_error_callback = {
    'title': 'Erreur',
    'message': 'Veuillez remplir votre email.'
}
var token_message_success_callback = {
    'title': 'Succès',
    'message': 'Envoyé! Merci de consulter vos emails.'
}
